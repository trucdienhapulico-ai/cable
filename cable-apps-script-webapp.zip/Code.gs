const SPREADSHEET_ID = '1TD2JsMVwRk0KXUCPbtRiKF4UePzfyiw5LX5FKzJwlHU';

function doGet() {
  return HtmlService.createTemplateFromFile('Index')
    .evaluate()
    .setTitle('Ultimate Cable Sizing Tool')
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}

function include(name) {
  return HtmlService.createHtmlOutputFromFile(name).getContent();
}

function getInitialData() {
  const ss = SpreadsheetApp.openById(SPREADSHEET_ID);
  return {
    settings: sheetObjects_(ss, 'Settings'),
    cables: sheetObjects_(ss, 'CableCatalog').filter(r => truthy_(r['Hoạt động'])),
    temperatureFactors: sheetObjects_(ss, 'TemperatureFactor'),
    groupingFactors: sheetObjects_(ss, 'GroupingFactor'),
    conduits: sheetObjects_(ss, 'ConduitCatalog').filter(r => truthy_(r['Hoạt động'])),
    projects: sheetObjects_(ss, 'Projects')
  };
}

function saveCableRecord(data) {
  const lock = LockService.getScriptLock();
  lock.waitLock(20000);
  try {
    validateRecord_(data);
    const ss = SpreadsheetApp.openById(SPREADSHEET_ID);
    const sheet = ss.getSheetByName('CableData');
    const now = new Date();
    const user = Session.getActiveUser().getEmail() || 'anonymous';
    const id = data.id || Utilities.getUuid();
    const version = Number(data.version || 1);

    const row = [
      id, version, now, user, safe_(data.project), safe_(data.cableCode),
      safe_(data.loadName), safe_(data.sourcePanel), safe_(data.destinationPanel),
      safe_(data.phase), num_(data.voltageV), num_(data.powerKw), num_(data.powerFactor),
      num_(data.efficiency), num_(data.lengthM), safe_(data.material), safe_(data.insulation),
      num_(data.reserveFactor), num_(data.ambientC), num_(data.groupedCircuits),
      num_(data.loadCurrentA), num_(data.designCurrentA), num_(data.cableSizeMm2),
      num_(data.parallelRuns), safe_(data.cableConfiguration), num_(data.correctedAmpacityA),
      num_(data.voltageDropV), num_(data.voltageDropPercent), safe_(data.conduitSize),
      safe_(data.status || 'Dự kiến'), safe_(data.notes)
    ];
    sheet.appendRow(row);

    ss.getSheetByName('ChangeLog').appendRow([
      now, user, 'CREATE', 'CableData', id, version,
      JSON.stringify({ cableCode: data.cableCode, configuration: data.cableConfiguration })
    ]);
    return { ok: true, id, version, row: sheet.getLastRow() };
  } finally {
    lock.releaseLock();
  }
}

function getRecentCableRecords(limit) {
  const ss = SpreadsheetApp.openById(SPREADSHEET_ID);
  const rows = sheetObjects_(ss, 'CableData');
  return rows.slice(-Math.min(Number(limit || 20), 100)).reverse();
}

function sheetObjects_(ss, sheetName) {
  const sheet = ss.getSheetByName(sheetName);
  if (!sheet || sheet.getLastRow() < 2) return [];
  const values = sheet.getDataRange().getValues();
  const headers = values.shift().map(String);
  return values
    .filter(row => row.some(v => v !== ''))
    .map(row => Object.fromEntries(headers.map((h, i) => [h, row[i]])));
}

function validateRecord_(data) {
  ['cableCode','loadName','sourcePanel','destinationPanel','voltageV','powerKw',
   'lengthM','cableSizeMm2','parallelRuns','voltageDropPercent'].forEach(key => {
    if (data[key] === undefined || data[key] === null || data[key] === '') {
      throw new Error('Thiếu dữ liệu: ' + key);
    }
  });
}

function safe_(v) {
  if (v === undefined || v === null) return '';
  const s = String(v);
  return /^[=+\-@]/.test(s) ? "'" + s : s;
}

function num_(v) {
  const n = Number(v);
  return Number.isFinite(n) ? n : '';
}

function truthy_(v) {
  return v === true || String(v).toLowerCase() === 'true' || Number(v) === 1;
}